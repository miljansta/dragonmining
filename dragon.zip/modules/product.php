<?
$products = array(
        array(
                'id' => 1,
                'title' => 'Product 01',
                'image' => 'image/product/product01.jpg',
                'description' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text
                                  ever since the 1500s"
            ),
        array(    
                'id' => 2,
                'title' => 'Product 02',
                'image' => 'image/product/product02.jpg',
                'description' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text
                                  ever since the 1500s"
            ),
    );

return $products;
?>
